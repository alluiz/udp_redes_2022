package br.edu.ufabc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.HashMap;

public class Main {

    private static DatagramSocket clientSocket;
    private static BufferedReader inFromUser;

    public static void main(String[] args) throws IOException {

        initClient();

        //Auto-connect
        sendRequest("connect");
        String responseMessage = getResponse();

        if (responseMessage.equals("connected")) {

            //Obtem entrada
            String requestMessage = getRequestMessage(true);

            //Verifica se o comando fim foi executado
            while (!requestMessage.equals("fim")) {

                //Envia mensagem
                sendRequest(requestMessage);
                getResponse();

                //Confirma recebimento da resposta
                sendRequest("received");
                getResponse();

                //Realiza a leitura de uma nova mensagem ou comando de fim
                requestMessage = getRequestMessage();
            }

            //Solicita fim da conexão
            sendRequest("disconnect");
            getResponse();

        }

        closeClient();

    }

    private static String getRequestMessage() throws IOException {
        return getRequestMessage(false);
    }

    private static String getRequestMessage(boolean skip) throws IOException {

        boolean continua = skip || Boolean.parseBoolean(getInput("continua (true or false)"));

        if (continua)
            return getParametersMessage();

        return "fim";

    }

    private static String getParametersMessage() throws IOException {
        String[] parameters = new String[]{"local", "dias"};
        String message = "";

        for (int i = 0; i < parameters.length; i++) {
            message += parameters[i] + "=" + getInput(parameters[i]) + "&";
        }

        return message.substring(0, message.length() - 1);
    }

    private static String getInput(String parameter) throws IOException {
        System.out.print(parameter + ":");
        return inFromUser.readLine();
    }

    private static void closeClient() {
        //Encerra o socket cliente e libera a porta
        clientSocket.close();
    }

    private static void initClient() throws SocketException {
        clientSocket = new DatagramSocket();
        inFromUser = new BufferedReader(new InputStreamReader(System.in));
    }

    private static String getResponse() throws IOException {

        byte[] receiveData = new byte[1024];

        //Processa o datagrama recebido do servidor
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
        clientSocket.receive(receivePacket);

        //Imprime a mensagem processada
        String response = new String(receivePacket.getData()).trim();

        System.out.println("Do servidor:" + response);

        return response;
    }

    private static void sendRequest(String requestMessage) throws IOException {

        InetAddress serverIpAddress = InetAddress.getByName("127.0.0.1");
        DatagramPacket sendPacket = new DatagramPacket(requestMessage.getBytes(), requestMessage.getBytes().length, serverIpAddress, 9876);
        clientSocket.send(sendPacket);
        System.out.println("Do cliente:" + requestMessage);

    }
}
