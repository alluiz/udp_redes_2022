package br.edu.ufabc;

import java.net.InetAddress;

public class Request {

    private InetAddress ip;
    private int port;
    private String message;

    public Request(InetAddress ip, int port, String message) {
        this.ip = ip;
        this.port = port;
        this.message = message;
    }

    public String getConnectionKey() {
        return ip.toString() + ":" + port;
    }

    public InetAddress getIp() {
        return ip;
    }

    public void setIp(InetAddress ip) {
        this.ip = ip;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
