package br.edu.ufabc;

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Main {

    private static HashMap<String, String> data;
    private static String[] columns;

    private static HashMap<String, InetAddress> connections = new HashMap<>();
    private static DatagramSocket serverSocket;

    public static void main(String args[]) throws Exception {

        initServer();
        initData();

        while (true) {

            //Obtem a requisição do cliente
            Request request = getRequest();

            //Verifica se está conectado
            String connectionKey = request.getConnectionKey();
            boolean isConnected = isConnected(connectionKey);
            boolean isOnWhitelist = false;

            //Se não, verifica se está na WhiteList
            if (!isConnected)
                isOnWhitelist = isOnWhiteList(request.getIp());

            boolean ableToProcess = isConnected || isOnWhitelist;

            String responseMessage = "denied"; //negado por padrão

            //Se conectado ou na whitelist, processa a requisição
            if (ableToProcess)
                responseMessage = isConnected ? processAfterConnectedMessage(request) : processBeforeConnectedMessage(request);

            sendResponse(request, responseMessage);
        }
    }

    private static String processBeforeConnectedMessage(Request request) {

        String responseMessage = "not connected";
        String requestMessage = request.getMessage();

        if (requestMessage.equals("connect")) {

            connect(request);
            responseMessage = "connected";

        }

        return responseMessage;
    }

    private static String processAfterConnectedMessage(Request request) {

        String responseMessage = "invalid";
        String requestMessage = request.getMessage();

        if (requestMessage.equals("disconnect")) {

            disconnect(request.getConnectionKey());
            responseMessage = "disconnected";

        } else if (requestMessage.contains("local") && requestMessage.contains("dias")) {

            responseMessage = getResponseMessage(requestMessage);

        } else if (requestMessage.equals("received")) {

            responseMessage = "waiting";

        }

        return responseMessage;
    }

    private static Request getRequest() throws IOException {

        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
        System.out.println("Servidor aguardando...");
        serverSocket.receive(receivePacket);
        InetAddress ipAddress = receivePacket.getAddress();
        int port = receivePacket.getPort();

        String requestMessage = new String(receiveData).trim();
        System.out.println("Do cliente:" + requestMessage);

        return new Request(ipAddress, port, requestMessage);

    }

    private static void initServer() throws SocketException {
        serverSocket = new DatagramSocket(9876);
    }

    private static void sendResponse(Request request, String responseMessage) throws IOException {
        byte[] sendData = responseMessage.getBytes();
        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, request.getIp(), request.getPort());
        serverSocket.send(sendPacket);
        System.out.println("Do servidor:" + responseMessage);
    }

    private static void initData() {
        data = new HashMap<>();
        data.put("SP-1", "Nublado,10.0,15,20");
        data.put("SP-2", "Ensolarado,15.0,10, 16");

        columns = new String[]{
                "clima",
                "umidade",
                "temp_min",
                "temp_max"};
    }

    private static String getResponseMessage(String requestMessage) {
        try {

            String responseMessage;
            HashMap<String, String> parameters = getParameters(requestMessage);
            String local = parameters.get("local");
            String dias = parameters.get("dias");
            String key = local + "-" + dias;

            responseMessage = getData(key);

            return responseMessage;

        } catch (Exception e) {
            System.out.println(e.toString());
            return "invalid";
        }
    }

    private static String getData(String key) {

        String responseMessage = "";

        if (data.containsKey(key)) {

            String basicData = data.get(key);
            String[] values = basicData.split(",");

            responseMessage = "key=" + key + "&";

            for (int i = 0; i < values.length; i++) {
                responseMessage += columns[i] + "=" + values[i] + "&";
            }

            responseMessage = responseMessage.substring(0, responseMessage.length() - 1);
        } else {
            responseMessage = "not found";
        }

        return responseMessage;
    }

    private static HashMap<String, String> getParameters(String message) {

        HashMap<String, String> parameters = new HashMap<>();
        String[] parametersWithValues = message.split("&");

        for (int i = 0; i < parametersWithValues.length; i++) {
            String[] parameter = parametersWithValues[i].split("=");
            parameters.put(parameter[0], parameter[1]);
        }

        return parameters;
    }

    private static void connect(Request request) {
        connections.put(request.getConnectionKey(), request.getIp());
        System.out.println("Conectado: " + request.getConnectionKey());
    }

    private static void disconnect(String connectionKey) {
        connections.remove(connectionKey);
        System.out.println("Desconectado: " + connectionKey);
    }

    private static boolean isConnected(String connectionKey) {
        return connections.containsKey(connectionKey);
    }

    private static boolean isOnWhiteList(InetAddress ipAddress) throws UnknownHostException {

        List<InetAddress> whiteList = new ArrayList<>();
        whiteList.add(InetAddress.getByName("127.0.0.1")); //apenas o ip do host local é aceito
        boolean isOnWhiteList = false;

        System.out.println("ClientIPAddress: " + ipAddress.toString());

        //valida a lista de IPs
        for (InetAddress whiteIp : whiteList) {
            //libera o IP se estiver na white list
            if (whiteIp.equals(ipAddress)) {
                isOnWhiteList = true;
                break;
            }
        }

        return isOnWhiteList;
    }
}
